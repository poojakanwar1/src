import React from 'react';
import Aux from '../Aux';
import classes from './Layout.module.css'
import Toolbar from '../../components/Navigation/Toolbar/Toolbar';
import EmployeeList from '../../containers/EmployeeList/EmployeeList';
import AddEmployee from '../../containers/AddEmployee/AddEmployee';
import EmployeeDetails from '../../containers/EmployeeDetails/EmployeeDetails';
import UpdateEmployee from '../../containers/UpdateEmployee/UpdateEmployee';

import { Route} from 'react-router-dom';

const layout = (props) => (
    <Aux>
       <Toolbar/>
       <Route path="/empList" exact component={EmployeeList} />
       <Route path="/addEmp" exact component={AddEmployee} />
       <Route path="/empDetail/:id" exact component={EmployeeDetails} />
       <Route path="/editEmpDetail/:id" exact component={UpdateEmployee} />

        <main className={classes.Content}>
            {props.children}
        </main>
    </Aux>
);

export default layout;