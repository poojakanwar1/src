import React, { Component } from 'react';
import Layout from './hoc/Layout/Layout'
import EmployeeDetails from '../src/components/Employee/EmployeeDetail/EmployeeDetail';
import EmployeeListTable from './components/Employee/EmployeeListTable/EmployeeListTable'
import { Route, Switch, withRouter, Redirect } from 'react-router-dom';

class App extends Component {
  render() {
    let routes = (
      <Switch>
        {/* <Route path="/" exact component={EmployeeDetails} /> */}
        {/* <Route path="/empDetail" exact component={EmployeeSkill} /> */}
      </Switch>
    );
    return (
      <div>
        
          <Layout>
            {routes}
          </Layout>
        
      </div>
    );
  }
}

export default App;
