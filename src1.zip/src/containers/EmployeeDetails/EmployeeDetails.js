import React, { Component } from 'react';
import EmpDetail from '../../components/Employee/EmployeeDetail/EmployeeDetail';
import { connect } from 'react-redux';
import * as actionCreators from '../../store/actions/index';

class EmployeeDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employeeModel: {
                employeeId: 0,
                firstName: "",
                lastName: "",
                dob: new Date(),
                email: "",
                sex: "",
                experiences: [],
                skills: []
            }
        };
    }

    componentDidMount() {
        this.props.onGetEmployeeDetail(this.props.match.params.id);
    }

    static getDerivedStateFromProps(props, state) {
        if (props.employeeDetail !== null && props.employeeDetail !== state.employeeModel) {
            var model = state.employeeModel;
            model.employeeId = props.employeeDetail.employeeId;
            model.firstName = props.employeeDetail.firstName;
            model.lastName = props.employeeDetail.lastName;
            model.sex = props.employeeDetail.sex;
            model.email = props.employeeDetail.email;
            model.dob = new Date(props.employeeDetail.dob);
            if (
                props.employeeDetail.experiences !== null &&
                props.employeeDetail.experiences !== undefined &&
                props.employeeDetail.experiences !== ""
            ) {
                model.experiences = props.employeeDetail.experiences;
            }
            if (
                props.employeeDetail.skills !== null &&
                props.employeeDetail.skills !== undefined &&
                props.employeeDetail.skills !== ""
            ) {
                model.skills = props.employeeDetail.skills;
            }
            return {
                employeeModel: model
            };
        }
    }

    render() {
        return (
            <EmpDetail employeeDetail={this.state.employeeModel}></EmpDetail>
        );
    }
}

const mapStateToProps = state => {
    return {
        employeeDetail: state.employeeDetail
    }
}

const mapDispatchToProps = dispatch => {
    return {
        onGetEmployeeDetail: (empId) => dispatch(actionCreators.initEmployeeDetail(empId))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(EmployeeDetails);

