import React, { Component } from 'react';
import AddEmployeeInfo from '../../components/Employee/AddEditEmployee/AddEmployeeInfo';
import { connect } from 'react-redux';
import * as actionCreators from '../../store/actions/index';

class AddEmployee extends Component {

    constructor(props) {
        debugger;
        super(props);
        this.state = {
            employeeId: 0,
            dob: new Date(),
            firstName: '',
            lastName: '',
            sex: '',
            email: '',
    }
}
   

componentDidMount() {
    
    debugger;
    console.log(this.state);
  
}

changeHandler = (event) => {
    debugger;
    console.log(this.state);
    const value = event.target.value;
    this.setState({
        ...this.state,
        [event.target.name]: value
    });
}
    render() {
        
        return (
            <div>
                <AddEmployeeInfo empForm={this.state} onChange={this.changeHandler}  ></AddEmployeeInfo>
            </div>
        );
    }
}



const mapStateToProps = state => {
    return {
        employeeDetail: state.employeeDetail
    }
}

const mapDispatchToProps = dispatch => {
    return {
        onAddEmployeeDetail: (val) => dispatch(actionCreators.setEmployeePersonalDetail(val))
    }
}


export default connect(mapStateToProps, mapDispatchToProps)(AddEmployee);