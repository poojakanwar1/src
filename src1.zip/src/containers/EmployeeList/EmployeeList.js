import React, { Component } from 'react';
import EmployeeListTable from '../../components/Employee/EmployeeListTable/EmployeeListTable';
import axios from '../../axios-employee';
import { textFilter } from 'react-bootstrap-table2-filter';
import Spinner from '../../components/UI/Spinner';
import { connect } from 'react-redux';
import ErrorHandler from '../../hoc/ErrorHandler/ErrorHandler'
import * as actionCreators from '../../store/actions/index';
import EmployeeDetails from '../EmployeeDetails/EmployeeDetails';
import Link from 'react-router-dom';
class EmployeeList extends Component {
    state = {
        employeeList: [],
        columns: [{
            dataField: 'employeeId',
            text: 'Employee ID',
            sort: true,
            formatter: (cellContent, row) => (
                <a href={"/empDetail/" + row.employeeId} component={EmployeeDetails}>{row.employeeId}</a>
            )
        }, {
            dataField: 'firstName',
            text: 'Employee Name',
            formatter: (cellContent, row) => (
                <label> {row.firstName + ' ' + row.lastName}
                </label>
            ),
            sort: true,
            filter: textFilter()
        }, {
            dataField: 'sex',
            text: 'Sex',
            sort: true
        }, {
            dataField: 'dob',
            text: 'DOB'
        }
        ],
        defaultSorted: [{
            dataField: 'employeeId',
            order: 'asc'
        }],
        error: false,
        loading: false
    }

    componentDidMount() {
        this.props.onGetEmployeeList();

        //this.setState({ loading: true });

        // axios.get('/employees')
        //     .then(response => {
        //         this.setState({ employeeList: response.data, loading: false });
        //         //this.setState({loading:true});
        //     })
        //     .catch(error => {
        //         this.setState({ error: true, loading: false });
        //     });
    }

    render() {
        let error = <p>Something went wrong!</p>
        let employeeList = <EmployeeListTable
            employeeList={this.props.empList}
            columns={this.state.columns}
            defaultSorted={this.state.defaultSorted}
        >
        </EmployeeListTable>;
        // if (this.state.loading) {
        //     employeeList = <Spinner />;
        // }
        if (!this.state.error) {
            return (<div>
                {employeeList}
            </div>);
        } else {
            return (
                <div><p>Something went wrong!</p></div>
            );
        }

    }
}

const mapStateToProps = state => {
    console.log("mapStateToProps");
    return {
        empList: state.employeeList
    }
}

const mapDispatchToProps = dispatch => {
    console.log("mapDispatchToProps");
    return {
        onGetEmployeeList: () => dispatch(actionCreators.initEmployeeList())
    }
    // onGetEmployeeList: () => dispatch(actionCreators.setEmployeeList())
}

export default connect(mapStateToProps, mapDispatchToProps)(EmployeeList);

