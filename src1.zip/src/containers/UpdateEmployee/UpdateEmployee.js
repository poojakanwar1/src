import React, { Component } from 'react';
import UpdateEmployeeInfo from '../../components/Employee/UpdateEmployee/UpdateEmployeeInfo';
import { connect } from 'react-redux';
import * as actionCreators from '../../store/actions/index';

class UpdateEmployee extends Component {

    constructor(props) {
        super(props);
        this.state = {
            employeeModel: {
                employeeId: 0,
                firstName: "",
                lastName: "",
                dob: new Date(),
                email: "",
                sex: "",
                experiences: [],
                skills: []
            }
        };
    }
    componentDidMount() {
        this.props.onGetEmployeeDetail(this.props.match.params.id);
    }

    static getDerivedStateFromProps(props, state) {
        if (props.employeeDetail !== null && props.employeeDetail !== state.employeeModel) {
            var model = state.employeeModel;
            model.employeeId = props.employeeDetail.employeeId;
            model.firstName = props.employeeDetail.firstName;
            model.lastName = props.employeeDetail.lastName;
            model.sex = props.employeeDetail.sex;
            model.email = props.employeeDetail.email;
            model.dob = new Date(props.employeeDetail.dob);
            if (
                props.employeeDetail.experiences !== null &&
                props.employeeDetail.experiences !== undefined &&
                props.employeeDetail.experiences !== ""
            ) {
                model.experiences = props.employeeDetail.experiences;
                // model.experiences.forEach(item => {
                // item.fromDate = new Date(item.fromDate);
                // item.toDate = new Date(item.toDate);
                // });
            }
            if (
                props.employeeDetail.skills !== null &&
                props.employeeDetail.skills !== undefined &&
                props.employeeDetail.skills !== ""
            ) {
                model.skills = props.employeeDetail.skills;
            }
            return {
                employeeModel: model
            };
        }
    }

    deleteSkillHandler = () => {
        alert("skill delete");
    }
    // static getDerivedStateFromProps(props, state) {
    //     if (props.employeeDetail !== null && props.employeeDetail !== state.employeeModel) {

    //         // fill employee model
    //         var model = state.employeeModel;
    //         model = props.employeeDetail;
    //         return {
    //             employeeModel: model
    //         };
    //     }
    //     return null;
    // }
    render() {
        return (
            <div>
                <UpdateEmployeeInfo skillsList={this.state.employeeModel.skills} experiencesList={this.state.employeeModel.experiences} employeeDetail={this.state.employeeModel} deleteSkill={this.deleteSkillHandler} ></UpdateEmployeeInfo>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        employeeDetail: state.employeeDetail
    }
}

const mapDispatchToProps = dispatch => {
    return {
        onGetEmployeeDetail: (empId) => dispatch(actionCreators.initEmployeeDetail(empId))
    }
}



export default connect(mapStateToProps, mapDispatchToProps)(UpdateEmployee);