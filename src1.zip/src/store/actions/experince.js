import * as actionTypes from './actionTypes';
import axios from 'axios';

export const setEmployeeExperienceList = (experiencesList) => {
    console.log("initEmployeeList");
    return {
        type: actionTypes.GET_EMPLOYEE_EXPERIENCE_LIST,
        experiencesList: experiencesList
    };
};

export const initEmployeeExperiencesList = () => {
    console.log("initEmployeeExperiencesList");
    return dispatch => {
            axios.get('http://13.94.203.73:1103/api/employees/63')
                .then(response => {
                    dispatch(setEmployeeExperienceList(response.data.experiences));
                })
    };
};