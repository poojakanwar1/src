import * as actionTypes from './actionTypes';
import axios from 'axios';

export const setEmployeeList = (employeeList) => {
    console.log("setEmployeeList action");
    return {
        type: actionTypes.GET_EMPLOYEE_LIST,
        employeeList: employeeList
    };
};

export const setEmployeeDetail = (employeeDetail) => {
    return {
        type: actionTypes.GET_EMPLOYEE_DETAIL,
        employeeDetail: employeeDetail
    };
};


export const setEmployeePersonalDetail = (val) => {
    return {
        type: actionTypes.SET_EMP_Personal_DETAIL,
        value: val
    };
};


export const setUpdateEmployeeDetail = (val) => {
    debugger;
    return {
        type: actionTypes.UPDATE_EMP_DETAIL,
        value: val
    };
};

export const setAddEmployeeDetail = (val) => {
    debugger;
    return {
        type: actionTypes.ADD_EMP_DETAIL,
        value: val
    };
};

export const initEmployeeList = () => {
    console.log("initEmployeeList");
    return dispatch => {
        axios.get('http://13.94.203.73:1103/api/employees')
            .then(response => {
                dispatch(setEmployeeList(response.data));
            })
    };
};

export const initEmployeeDetail = (id) => {
    return dispatch => {
        axios.get('http://13.94.203.73:1103/api/employees/' + id)
            .then(response => {
                dispatch(setEmployeeDetail(response.data));
            })
    };
};

export const updateEmployeeDetail = (data) => {
    return dispatch => {
        axios.post('http://13.94.203.73:1103/api/employees/' + data.id, data)
            .then(response => {
                dispatch(setUpdateEmployeeDetail(response.data));
            })
    };
};

export const addEmployeeDetail = (data) => {
    return dispatch => {
        axios.post('http://13.94.203.73:1103/api/employees/',data)
            .then(response => {
                dispatch(setAddEmployeeDetail(response.data));
            })
    };
};
