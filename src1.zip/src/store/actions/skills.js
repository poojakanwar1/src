import * as actionTypes from './actionTypes';
import axios from 'axios';

export const setEmployeeSkillsList = (skillsList) => {
    return {
        type: actionTypes.GET_EMPLOYEE_SKILLS_LIST,
        skillsList: skillsList
    };
};

export const initEmployeeSkillsList = () => {
    return dispatch => {
            axios.get('http://13.94.203.73:1103/api/employees/63')
                .then(response => {
                    dispatch(setEmployeeSkillsList(response.data.skills));
                })
    };
};