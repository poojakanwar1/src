import React from 'react';
import { updateObject } from '../../shared/utility';
import * as actionTypes from '../actions/actionTypes';
const initialState = {
    employeeList: [],
    skillsList:[],
    experiencesList:[],
    employeeDetail:[],
    
}


const setEmployeeList = (state, action) => {
    return updateObject( state, {
        employeeList: action.employeeList
    } );
};

const setEmployeeSkillsList = (state, action) => {
    return updateObject( state, {
        skillsList: action.skillsList
    } );
};

const setEmployeeExperincesList = (state, action) => {
    return updateObject( state, {
        experiencesList: action.experiencesList
    } );
};

const setEmployeeDetail = (state, action) => {
    return updateObject( state, {
        employeeDetail: action.employeeDetail
    } );
};

const setEmployeePersonalDetail = (state, action) => {
    debugger;
    return updateObject( state, {
        employeeDetail: action.employeeDetail
    } );
};
const reducer = (state = initialState, action) => {
    switch ( action.type ) {
        case actionTypes.GET_EMPLOYEE_LIST: return setEmployeeList( state, action );
        case actionTypes.GET_EMPLOYEE_SKILLS_LIST: return setEmployeeSkillsList( state, action );
        case actionTypes.GET_EMPLOYEE_EXPERIENCE_LIST: return setEmployeeExperincesList( state, action );
        case actionTypes.GET_EMPLOYEE_DETAIL: return setEmployeeDetail( state, action );
        case actionTypes.SET_EMP_Personal_DETAIL: return setEmployeePersonalDetail( state, action );
    }
    return  state;
}
export default reducer;