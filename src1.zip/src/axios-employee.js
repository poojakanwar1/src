// axios instance if we do not want to sent the baseURL globly in index.js 
import axios from 'axios';

const instance =  axios.create({
    baseURL: 'http://13.94.203.73:1103/api'
});

export default instance;