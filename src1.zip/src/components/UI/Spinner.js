import React from 'react'
import Spinner from 'react-bootstrap/Spinner'

const spinner = () => (
    <div class="d-flex justify-content-center">
        <Spinner animation="border" variant="secondary" role="status">
            <span className="sr-only">Loading...</span>
        </Spinner>
    </div>
);


export default spinner;
