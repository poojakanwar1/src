import React from 'react';
import Navbar from 'react-bootstrap/Navbar';
import EmployeeSkillLogo from '../../../assets/images/vector_913_32-512.png'
import classes from '../../Logo/Logo.module.css';
import Nav from 'react-bootstrap/Nav';
import { Link, NavLink } from 'react-router-dom';

const toolbar = (props) => (
    <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Navbar.Brand href="#home" alt="Employee skill logo" className={classes.navbarBrand}>
            <img src={EmployeeSkillLogo} alt="Employee skill logo" />
        Employee-Skills
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="mr-auto" >
                
            {/* <Nav.Link to="/">Home</Nav.Link>
            <Nav.Link to="/empDetail">Employee Detail</Nav.Link>
            <Nav.Link to="/addEmp">Add Employee</Nav.Link> */}
                <NavLink className="nav-link" to="/" exact>Home</NavLink>
                <NavLink className="nav-link" to="/empList">Employees</NavLink>
                <NavLink className="nav-link" to="/addEmp">Add Employee</NavLink>
                {/* <Nav.Link href="/">Home</Nav.Link>
                <Nav.Link href="/empDetail">Employee Detail</Nav.Link>
                <Nav.Link href="/addEmp">Add Employee</Nav.Link> */}

                {/* <NavDropdown title="Dropdown" id="basic-nav-dropdown">
                    <NavDropdown.Item href="#action">Action</NavDropdown.Item>
                    <NavDropdown.Item href="#action">Anotheraction</NavDropdown.Item>
                    <NavDropdown.Item href="#action">Something</NavDropdown.Item>
                    <NavDropdown.Divider />
                    <NavDropdown.Item href="#action">Separated link</NavDropdown.Item>
                </NavDropdown> */}
            </Nav>
            <Nav>
                <Nav.Link href="#deets">More deets</Nav.Link>
                <Nav.Link eventKey={2} href="#memes">
                    Dank memes
      </Nav.Link>
            </Nav>
        </Navbar.Collapse>
    </Navbar>
);

export default toolbar;