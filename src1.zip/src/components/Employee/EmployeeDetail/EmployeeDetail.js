import React, { Component } from 'react';
import EmpSkillsList from '../EmpSkillsList/EmpSkillList';
import EmpExperinceList from '../EmpExperinceList/EmpExperinceList';
import Moment from 'moment';
class EmployeeDetails extends Component {
    state = {
        startDate: new Date(),
        empSkills: [{}],
        empExpDetail: [{}],
        skillColumns: [{
            dataField: 'skill',
            text: 'Skill',
        }, {
            dataField: 'level',
            text: 'Level',
        }
        ],
        experinceColumns: [{
            dataField: 'company',
            text: 'Company',
        }, {
            dataField: 'designation',
            text: 'Designation',
        }, {
            dataField: 'fromDate',
            text: 'From Date',
        }, {
            dataField: 'toDate',
            text: 'To Date'
        }
        ]
    };

    render() {
        return (
            <div className="container">
                <div className="well">
                    <form className="form-horizontal border bg-light border-secondary">
                        <h3 className="text-center sticky-top">Employee Personal Details
                        <div className="float-right">
                                <a href={"/editEmpDetail/" + this.props.employeeDetail.employeeId} className="btn btn-outline-dark mr-4 font-weight-bold" role="button" aria-pressed="true">Edit</a>
                            </div>
                        </h3>
                        <hr />
                        <div className="form-group row">
                            <label className="control-label col-sm-2 ml-4 font-weight-bold">ID:</label>
                            <div className="form-control-static col-sm-7">
                                <label>{this.props.employeeDetail.employeeId}</label>
                            </div>
                        </div>
                        <div className="form-group row">
                            <label className="control-label col-sm-2  ml-4 font-weight-bold">First Name:</label>
                            <div className="form-control-static col-sm-3">
                                <label>{this.props.employeeDetail.firstName}</label>
                            </div>
                            <label className="control-label col-sm-2  ml-4 font-weight-bold font-weight-bold">Last Name:</label>
                            <div className="form-control-static col-sm-3">
                                <label>{this.props.employeeDetail.lastName}</label>
                            </div>
                        </div>
                        <div className="form-group row">
                            <label className="control-label col-sm-2  ml-4 font-weight-bold">Date Of Birth:</label>
                            <div className="form-control-static col-sm-3">
                                <label>{Moment(this.props.employeeDetail.dob).format('d MMM yyyy')}</label>
                            </div>
                            <label className="control-label col-sm-2  ml-4 font-weight-bold">Gender:</label>
                            <div className="form-control-static col-sm-3">
                                <label>{this.props.employeeDetail.sex}</label>
                            </div>
                        </div>
                        <div className="form-group row">
                            <label className="control-label col-sm-2  ml-4 font-weight-bold">Email:</label>
                            <div className="form-control-static col-sm-3">
                                <label>{this.props.employeeDetail.email}</label>
                            </div>
                        </div>
                        <h3 className="text-center">Employee Skills Details</h3>
                        <div className="form-group row col-sm-12 ml-1">
                            <EmpSkillsList skillsDetail={this.props.employeeDetail.skills} columns={this.state.skillColumns}></EmpSkillsList>
                        </div>
                        <h3 className="text-center">Employee Professional Details</h3>
                        <div className="form-group row col-sm-12 ml-1">
                            <EmpExperinceList empExpDetail={this.props.employeeDetail.experiences} columns={this.state.experinceColumns}></EmpExperinceList>
                        </div>
                    </form>
                </div>
            </div>
        );
    }
};

export default EmployeeDetails;