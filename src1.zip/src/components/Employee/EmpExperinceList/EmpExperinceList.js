import React from 'react';
import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';

const EmpExperinceList = (props) => {
    // const selectRow = {
    //     mode: 'radio',
    //     clickToSelect: true,
    //     classes: (row, rowIndex) => {
    //         return alert("hello click" + rowIndex);
    //     }
    // };
    return (
        <BootstrapTable
            keyField='id'
            data={props.empExpDetail}
            columns={props.columns}
            striped
            hover
            condensed
            noDataIndication="Table is Empty"
            headerClasses="header-class"
        />
    );
};

export default EmpExperinceList;