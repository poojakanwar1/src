import React, { Component } from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import EmpExperinceList from '../../EmpExperinceList/EmpExperinceList';

class AddPastExperince extends Component {
    state = {
        fromDate: new Date(),
        toDate: new Date(),
        columns: [{
            dataField: 'company',
            text: 'Company',
        }, {
            dataField: 'designation',
            text: 'Designation',
        }, {
            dataField: 'fromDate',
            text: 'From Date',
        }, {
            dataField: 'toDate',
            text: 'To Date'
        }
        ],
        empExpList: [
            //{

            // company:'evry',
            // designation:'SSE',
            // fromDate:'2019-23-3',
            // toDate:'2019-23-3'
            //    }
        ]
    };

    handleFromdateChange =(date )=> {
        this.setState({
            fromDate: date
        });
    };

    
    handleTodateChange =(date )=> {
        this.setState({
            toDate: date
        });
    };
    render() {

        return (
            <div className="container ">
                <div className="row">
                    <div className="form-group  col-md-6 ">
                        <label>Company Name</label>
                        <input type="text" className="form-control" id="exampleInputName2" placeholder="Jane Doe" />
                    </div>
                    <div className="form-group col-md-6">
                        <label >Designation</label>
                        <input type="email" className="form-control" id="exampleInputEmail2" placeholder="jane.doe@example.com" />
                    </div>
                </div>

                <div className="row">
                    <div className="form-group  col-md-6 ">
                        <label>From date</label><br />
                        <DatePicker name="fromDate" className="form-control"
                            selected={this.state.fromDate}
                            onChange={this.handleFromdateChange} />
                    </div>
                    <div className="form-group  col-md-6 ">
                        <label>To date</label><br />
                        <DatePicker name="toDate" className="form-control"
                            selected={this.state.toDate}
                            onChange={this.handleTodateChange} />

                    </div>
                </div>
                <div className="row">
                    <div className="form-group  col-md-6 ">
                        <button>Add</button>
                    </div>
                </div>
                <div className="row">
                    <div className="form-group  col-md-6 ">
                        <EmpExperinceList empExpDetail={this.state.empExpList} columns={this.state.columns}></EmpExperinceList>
                    </div>
                </div>
            </div>
        );
    }
}

export default AddPastExperince;


