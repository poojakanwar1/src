import React, { Component } from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import UpdateEmployee from '../../../../containers/UpdateEmployee/UpdateEmployee';

class AddPersonalInfo extends Component {

    constructor(props) {
        super(props);
        this.state = {
            dob: new Date(),
            firstName: '',
            lastName: '',
            sex: '',
            email: ''
        };
        //this.props.changeHandler = this.props.changeHandler.bind(this);
    }
 
    handleChange = date => {
        this.setState({
            dob: date
        });
    };

    static getDerivedStateFromProps(props, state) {
        console.log('[App.js] getDerivedStateFromProps', props);
        return state;
      }
  
        //  this.setState({ [event.target.name]: event.target.value });
        // console.log(event.target.value);
        // const updateEmployeeForm = {
        //     ...this.state.employeeForm
        // }
        // const updateFormElement = {
        //     ...updateEmployeeForm["firstName"]
        // }
        // updateEmployeeForm.firstName = event.target.value;
        // // // updateFormElement.value = event.target.value;
        //  //UpdateEmployeeForm[inputIdentifier] = updateFormElement;
        // this.setState({ employeeForm: UpdateEmployeeForm });
    render() {
        const date = new Date(this.state.dob);
        let form = (
            <div className="container ">
                <div className="row">
                    <div className="form-group  col-md-6 ">
                        <label>First Name</label>
                        <input type="text" className="form-control" id="firstnamne" name="firstName" placeholder="Pooja" value={this.props.firstName}
                            onChange={this.props.changeHandler} />
                    </div>
                    <div className="form-group col-md-6">
                        <label >Last Name</label>
                        <input type="email" className="form-control" id="lastname" placeholder="Kanwar" name="lastName" value={this.props.lastName} onChange={this.changeHandler} />
                    </div>
                </div>
                <div className="row">
                    <div className="form-group  col-md-6 ">
                        <label>Email</label>
                        <input type="text" className="form-control" id="email" placeholder="Pooja@evry.com" name="email" value={this.props.email} onChange={this.changeHandler} />
                    </div>
                    <div className="form-group col-md-6">
                        <label >Sex</label>
                        <select name="sex" value={this.props.sex} onChange={this.changeHandler} className="browser-default custom-select">
                            <option defaultValue>Open this select menu</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Transgender">Transgender</option>
                        </select>
                    </div>
                </div>

                <div className="row">
                    <div className="form-group  col-md-12 ">
                        <label>Date of Birth</label><br />
                        <DatePicker className="form-control"
                            selected={this.state.dob}
                            onChange={this.handleChange}
                            onSelect={this.handleSelect} /><br />

                    </div>
                </div>
            </div>
        );
        return (
            <div>
                {form}
            </div>
        );
    }
}

export default AddPersonalInfo;


