import React, { Component } from 'react';
import "react-datepicker/dist/react-datepicker.css";
import EmpSkillsList from '../../EmpSkillsList/EmpSkillList';


class AddSkills extends Component {
    state = {
        columns: [{
            dataField: 'skill',
            text: 'Skill',
        }, {
            dataField: 'level',
            text: 'Level',
        }
        ],
        empSkills: [
            //      {
            // skill:'MVC',level:'4',
            // skill:'React',level:'3',
            // skill:'Oracle',level:'2'
            //    }
        ]
    };
    render() {
        return (
            <div className="container ">
                <div className="row">
                    <div className="form-group  col-md-6 ">
                        <label >Skill</label>
                        <select className="browser-default custom-select">
                            <option defaultValue>-- Select Skill --</option>
                            <option value="1">Asp .net</option>
                            <option value="2">MVC</option>
                            <option value="3">LINQ</option>
                            <option value="3">Sql</option>
                            <option value="3">Oracle</option>
                            <option value="3">React</option>
                            <option value="3">Angular</option>
                            <option value="3">CSS</option>
                        </select>
                    </div>
                    <div className="form-group col-md-6">
                        <label >Level</label>
                        <select className="browser-default custom-select">
                            <option defaultValue>-- Select Level --</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                </div>
                <div className="row">
                    <div className="form-group  col-md-6 ">
                        <button>Add</button>
                    </div>
                </div>
                <div className="row">
                    <div className="form-group  col-md-6 ">
                        <EmpSkillsList skillsDetail={this.state.empSkills} columns={this.state.columns}></EmpSkillsList>
                    </div>
                </div>
            </div>
        );
    }
}

export default AddSkills;


