import React, { Component } from 'react';
import Accordion from 'react-bootstrap/Accordion'
import Card from 'react-bootstrap/Card';
import AddPersonalInfo from '../AddEditEmployee/AddPersonalInfo/AddPersonalInfo';
import AddPastExperince from '../AddEditEmployee/AddPastExperince/AddPastExperince';
import AddSkills from '../AddEditEmployee/AddSkills/AddSkills';
import * as classes from '../../Employee/Employee.module.css';

class AddEmployeeInfo extends Component {
  postDataHandler = () => {
    debugger;
    const employee ={
      firstName:this.props.firstName,
      lastName:this.props.firstName,
      sex:this.props.firstName,
      dob:this.props.firstName,
      email:this.props.firstName
    }
  }
  render() {
    return (

      <div>
        <Accordion defaultActiveKey="0">
          <Card>
            <Accordion.Toggle as={Card.Header} eventKey="0">
              Personal Information
    </Accordion.Toggle>
            <Accordion.Collapse eventKey="0">
              <Card.Body><AddPersonalInfo empForm={this.props.empForm}></AddPersonalInfo></Card.Body>
            </Accordion.Collapse>
          </Card>
          <Card>
            <Accordion.Toggle as={Card.Header} eventKey="1">
              Professional Experience
    </Accordion.Toggle>
            <Accordion.Collapse eventKey="1">
              <Card.Body><AddPastExperince  ></AddPastExperince></Card.Body>
            </Accordion.Collapse>
          </Card>
          <Card>
            <Accordion.Toggle as={Card.Header} eventKey="2">
              Skills Information
    </Accordion.Toggle>
            <Accordion.Collapse eventKey="2">
              <Card.Body><AddSkills ></AddSkills></Card.Body>
            </Accordion.Collapse>
          </Card>
        </Accordion>
        <button onClick={this.postDataHandler}>Save Info</button>
      </div>
    );
  }
}
export default AddEmployeeInfo;