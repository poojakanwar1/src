import React, { Component } from 'react';
import Accordion from 'react-bootstrap/Accordion'
import Card from 'react-bootstrap/Card';
import UpdatePersonalInfo from '../UpdateEmployee/UpdatePersonalInfo/UpdatePersonalInfo';
import UpdateExperince from '../UpdateEmployee/UpdateExperince/UpdateExperince';
import UpdateSkills from '../UpdateEmployee/UpdateSkills/UpdateSkills';
import * as classes from '../../Employee/Employee.module.css';
import { render } from '@testing-library/react';

class UpdateEmployeeInfo extends Component {
  postDataHandler=()=>{
alert("sdsfs");
  }
  render() {
    return (
      <div>
        <Accordion defaultActiveKey="0">
          <Card>
            <Accordion.Toggle as={Card.Header} eventKey="0">
              Personal Information
    </Accordion.Toggle>
            <Accordion.Collapse eventKey="0">
              <Card.Body><UpdatePersonalInfo employeeDetail={this.props.employeeDetail}></UpdatePersonalInfo></Card.Body>
            </Accordion.Collapse>
          </Card>
          <Card>
            <Accordion.Toggle as={Card.Header} eventKey="1">
              Professional Experience
    </Accordion.Toggle>
            <Accordion.Collapse eventKey="1">
              <Card.Body><UpdateExperince empExpList={this.props.experiencesList}></UpdateExperince></Card.Body>
            </Accordion.Collapse>
          </Card>
          <Card>
            <Accordion.Toggle as={Card.Header} eventKey="2">
              Skills Information
    </Accordion.Toggle>
            <Accordion.Collapse eventKey="2">
              <Card.Body><UpdateSkills empSkills={this.props.skillsList} skillDelete={this.props.deleteSkill}></UpdateSkills></Card.Body>
            </Accordion.Collapse>
          </Card>
        </Accordion>
        <button onClick={this.postDataHandler}>Save Info</button>
      </div>
    );
  }
}

export default UpdateEmployeeInfo;