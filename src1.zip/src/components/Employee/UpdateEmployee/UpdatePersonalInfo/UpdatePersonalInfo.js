import React, { Component } from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

class UpdatePersonalInfo extends Component {
    state = {
        startDate: new Date(),
        personalInfo: { employeeId: "3", firstName: "Pooja", lastName: "Kanwar", dob: "1985-08-30T09:30:00", sex: "female", email: "pooja.kanwar@evry.com" }
    };

    handleChange = date => {
        this.setState({
            startDate: date
        });
    };

    render() {
        const date = new Date(this.state.personalInfo.dob);
        return (
            <div className="container ">
                <div className="row">
                    <div className="form-group  col-md-6 ">
                        <label>First Name</label>
                        <input type="text" className="form-control" id="exampleInputName2" placeholder="Pooja" value={this.props.employeeDetail.firstName} />
                    </div>
                    <div className="form-group col-md-6">
                        <label >Last Name</label>
                        <input type="email" className="form-control" id="exampleInputEmail2" placeholder="Kanwar" value={this.props.employeeDetail.lastName} />
                    </div>
                </div>
                <div className="row">
                    <div className="form-group  col-md-6 ">
                        <label>Email</label>
                        <input type="text" className="form-control" id="exampleInputName3" placeholder="Pooja@evry.com" value={this.props.employeeDetail.email} />
                    </div>
                    <div className="form-group col-md-6">
                        <label >Sex</label>
                        <select value={this.props.employeeDetail.sex} className="browser-default custom-select">
                            <option defaultValue>Open this select menu</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Transgender">Transgender</option>
                        </select>
                    </div>
                </div>

                <div className="row">
                    <div className="form-group  col-md-12 ">
                        <label>Date of Birth</label><br />
                        <DatePicker className="form-control"
                            selected={date}
                            onChange={this.handleChange} /><br />

                    </div>
                </div>
            </div>
        );
    }
}

export default UpdatePersonalInfo;


