import React from 'react';
import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';

const EmpSkillsList = (props) => {
    const selectRow = {
        mode: 'checkbox',
        clickToSelect: true,
        classes: (row, rowIndex) => {
            console.log(rowIndex);
            console.log(row);
            //const personIndex = this.state.persons.findIndex(p => {
              //   p.id === id;
        //     const persons = props.skillsDetail;
        //    console.log(props.skillsDetail);
        //    console.log(persons);
        //    persons.splice(rowIndex, 1);
        //    console.log(persons);
        }
    };
    return (
        <BootstrapTable
            keyField='id'
            data={props.skillsDetail}
            columns={props.columns}
            striped
            hover
            condensed
            noDataIndication="Table is Empty"
            headerClasses="header-class"
            selectRow={ selectRow }
        />
    );
};

export default EmpSkillsList;