import React from 'react';
import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import paginationFactory from 'react-bootstrap-table2-paginator';
import filterFactory from 'react-bootstrap-table2-filter';
const EmployeeListTable = (props) => {
    // const selectRow = {
    //     mode: 'radio',
    //     clickToSelect: true,
    //     classes: (row, rowIndex) => {
    //         return alert("hello click" + rowIndex);
    //     }
    // };
    return (
        <BootstrapTable
            keyField='employeeId'
            data={props.employeeList}
            columns={props.columns}
            striped
            hover
            condensed
            noDataIndication="Table is Empty"
            defaultSorted={props.defaultSorted}
            pagination={paginationFactory()}
            filter={filterFactory()}
            headerClasses="header-class"
        />
    );
};

export default EmployeeListTable;